// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAGLNXV30w7fD2iR_zAR5kHWzoz33EvxXk",
  authDomain: "autocare-app-f207e.firebaseapp.com",
  projectId: "autocare-app-f207e",
  storageBucket: "autocare-app-f207e.firebasestorage.app",
  messagingSenderId: "760851728287",
  appId: "1:760851728287:web:60e5b48986da117ec4dfaa",
  measurementId: "G-SG45SXP0TH"
};